
# Windows 10 Online Emulator

Windows 10 Online Emulator is a website where you take a experience of Windows 10 in your broswer.

# Features

- [x]  Windows Start Menu
- [x]  Windows Search Menu
- [x]  Microsoft Edge
- [x]  Microsoft Store
- [x]  Minecraft
- [x]  Adobe Photoshop
- [x]  Visual Studio Code
- [ ]  This Pc
- [ ]  Recycle Bin
- [ ]  Microsoft Word
- [ ]  Microsoft Excel


# Screenshots
![screenshot-1](https://github.com/Web-Jit/Windows-10-Emulator/blob/main/images/screenshot-1.png?raw=true)

![screenshot-2](https://github.com/Web-Jit/Windows-10-Emulator/blob/main/images/screenshot-2.png?raw=true)

![screenshot-3](https://github.com/Web-Jit/Windows-10-Emulator/blob/main/images/screenshot-3.png?raw=true)


## Thanks for Reading 

